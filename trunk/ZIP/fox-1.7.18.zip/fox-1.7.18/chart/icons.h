/*********** Generated on 2008/11/24 17:49:38 by reswrap version 5.1.1 *********/

/* Created by reswrap from file marble.bmp */
extern const unsigned char marble[];

