/*********** Generated on 2008/11/24 17:50:04 by reswrap version 5.1.1 *********/

/* Created by reswrap from file adie_gif.gif */
extern const unsigned char adie_gif[];

/* Created by reswrap from file big_gif.gif */
extern const unsigned char big_gif[];

/* Created by reswrap from file bookdel_gif.gif */
extern const unsigned char bookdel_gif[];

/* Created by reswrap from file booknext_gif.gif */
extern const unsigned char booknext_gif[];

/* Created by reswrap from file bookprev_gif.gif */
extern const unsigned char bookprev_gif[];

/* Created by reswrap from file bookset_gif.gif */
extern const unsigned char bookset_gif[];

/* Created by reswrap from file browser.gif */
extern const unsigned char browser[];

/* Created by reswrap from file capitalize.gif */
extern const unsigned char capitalize[];

/* Created by reswrap from file close_gif.gif */
extern const unsigned char close_gif[];

/* Created by reswrap from file colors_gif.gif */
extern const unsigned char colors_gif[];

/* Created by reswrap from file config_gif.gif */
extern const unsigned char config_gif[];

/* Created by reswrap from file copy_gif.gif */
extern const unsigned char copy_gif[];

/* Created by reswrap from file cut_gif.gif */
extern const unsigned char cut_gif[];

/* Created by reswrap from file delete_gif.gif */
extern const unsigned char delete_gif[];

/* Created by reswrap from file delimit_gif.gif */
extern const unsigned char delimit_gif[];

/* Created by reswrap from file fonts_gif.gif */
extern const unsigned char fonts_gif[];

/* Created by reswrap from file help_gif.gif */
extern const unsigned char help_gif[];

/* Created by reswrap from file indent_gif.gif */
extern const unsigned char indent_gif[];

/* Created by reswrap from file info_gif.gif */
extern const unsigned char info_gif[];

/* Created by reswrap from file lang_gif.gif */
extern const unsigned char lang_gif[];

/* Created by reswrap from file lowercase.gif */
extern const unsigned char lowercase[];

/* Created by reswrap from file new_gif.gif */
extern const unsigned char new_gif[];

/* Created by reswrap from file nobrowser.gif */
extern const unsigned char nobrowser[];

/* Created by reswrap from file open_gif.gif */
extern const unsigned char open_gif[];

/* Created by reswrap from file palette_gif.gif */
extern const unsigned char palette_gif[];

/* Created by reswrap from file pattern_gif.gif */
extern const unsigned char pattern_gif[];

/* Created by reswrap from file paste_gif.gif */
extern const unsigned char paste_gif[];

/* Created by reswrap from file print_gif.gif */
extern const unsigned char print_gif[];

/* Created by reswrap from file quit_gif.gif */
extern const unsigned char quit_gif[];

/* Created by reswrap from file redo_gif.gif */
extern const unsigned char redo_gif[];

/* Created by reswrap from file reload_gif.gif */
extern const unsigned char reload_gif[];

/* Created by reswrap from file saveall_gif.gif */
extern const unsigned char saveall_gif[];

/* Created by reswrap from file saveas_gif.gif */
extern const unsigned char saveas_gif[];

/* Created by reswrap from file save_gif.gif */
extern const unsigned char save_gif[];

/* Created by reswrap from file search_gif.gif */
extern const unsigned char search_gif[];

/* Created by reswrap from file searchnext_gif.gif */
extern const unsigned char searchnext_gif[];

/* Created by reswrap from file searchprev_gif.gif */
extern const unsigned char searchprev_gif[];

/* Created by reswrap from file shiftleft_gif.gif */
extern const unsigned char shiftleft_gif[];

/* Created by reswrap from file shiftright_gif.gif */
extern const unsigned char shiftright_gif[];

/* Created by reswrap from file small_gif.gif */
extern const unsigned char small_gif[];

/* Created by reswrap from file styles_gif.gif */
extern const unsigned char styles_gif[];

/* Created by reswrap from file syntax_gif.gif */
extern const unsigned char syntax_gif[];

/* Created by reswrap from file undo_gif.gif */
extern const unsigned char undo_gif[];

/* Created by reswrap from file uppercase.gif */
extern const unsigned char uppercase[];

