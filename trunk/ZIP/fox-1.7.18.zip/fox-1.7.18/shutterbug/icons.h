/*********** Generated on 2008/11/24 17:50:02 by reswrap version 5.1.1 *********/

/* Created by reswrap from file line_0.gif */
extern const unsigned char line_0[];

/* Created by reswrap from file line_1.gif */
extern const unsigned char line_1[];

/* Created by reswrap from file line_2.gif */
extern const unsigned char line_2[];

/* Created by reswrap from file line_3.gif */
extern const unsigned char line_3[];

/* Created by reswrap from file line_4.gif */
extern const unsigned char line_4[];

/* Created by reswrap from file line_5.gif */
extern const unsigned char line_5[];

/* Created by reswrap from file line_6.gif */
extern const unsigned char line_6[];

/* Created by reswrap from file line_7.gif */
extern const unsigned char line_7[];

/* Created by reswrap from file line_8.gif */
extern const unsigned char line_8[];

/* Created by reswrap from file shutterbug.gif */
extern const unsigned char shutterbug[];

/* Created by reswrap from file tinyshutterbug.gif */
extern const unsigned char tinyshutterbug[];

