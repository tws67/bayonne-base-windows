/*********** Generated on 2008/11/24 17:50:11 by reswrap version 5.1.1 *********/

/* Created by reswrap from file controlpanel_gif.gif */
extern const unsigned char controlpanel_gif[];

/* Created by reswrap from file colors_gif.gif */
extern const unsigned char colors_gif[];

/* Created by reswrap from file filebinding_gif.gif */
extern const unsigned char filebinding_gif[];

/* Created by reswrap from file settings_gif.gif */
extern const unsigned char settings_gif[];

