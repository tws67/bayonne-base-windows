namespace FX {

extern const unsigned char arrownext[];

extern const unsigned char arrowprev[];

extern const unsigned char bigapp[];

extern const unsigned char bigcdrom[];

extern const unsigned char bigcomputer[];

extern const unsigned char bigdesktop[];

extern const unsigned char bigdoc[];

extern const unsigned char bigfloppy[];

extern const unsigned char bigfolder[];

extern const unsigned char bigfolderopen[];

extern const unsigned char bignetdrive[];

extern const unsigned char bignethood[];

extern const unsigned char bookset[];

extern const unsigned char bookclr[];

extern const unsigned char cmymode[];

extern const unsigned char dialmode[];

extern const unsigned char dirupicon[];

extern const unsigned char deleteicon[];

extern const unsigned char docktop[];

extern const unsigned char dockbottom[];

extern const unsigned char dockleft[];

extern const unsigned char dockright[];

extern const unsigned char dockfree[];

extern const unsigned char dockflip[];

extern const unsigned char entericon[];

extern const unsigned char erroricon[];

extern const unsigned char eyedrop[];

extern const unsigned char filecancel[];

extern const unsigned char fileaccept[];

extern const unsigned char filecopy[];

extern const unsigned char filemove[];

extern const unsigned char filehidden[];

extern const unsigned char filelink[];

extern const unsigned char filerename[];

extern const unsigned char filedelete[];

extern const unsigned char fileshown[];

extern const unsigned char foldernew[];

extern const unsigned char gotohome[];

extern const unsigned char gotoicon[];

extern const unsigned char gotowork[];

extern const unsigned char hsvmode[];

extern const unsigned char infoicon[];

extern const unsigned char landscape[];

extern const unsigned char listmode[];

extern const unsigned char miniapp[];

extern const unsigned char minicdrom[];

extern const unsigned char minicomputer[];

extern const unsigned char minidesktop[];

extern const unsigned char minidoc[];

extern const unsigned char minifloppy[];

extern const unsigned char minifolder[];

extern const unsigned char minifolderopen[];

extern const unsigned char miniharddisk[];

extern const unsigned char mininetdrive[];

extern const unsigned char mininethood[];

extern const unsigned char minizipdrive[];

extern const unsigned char portrait[];

extern const unsigned char questionicon[];

extern const unsigned char rgbmode[];

extern const unsigned char searchicon[];

extern const unsigned char showbigicons[];

extern const unsigned char showdetails[];

extern const unsigned char showsmallicons[];

extern const unsigned char warningicon[];

extern const unsigned char winclose[];

extern const unsigned char winmaximize[];

extern const unsigned char winminimize[];

extern const unsigned char winrestore[];

}
