/*********** Generated on 2008/11/24 17:50:08 by reswrap version 5.1.1 *********/

/* Created by reswrap from file bigicons.bmp */
extern const unsigned char bigicons[];

/* Created by reswrap from file closepanel.gif */
extern const unsigned char closepanel[];

/* Created by reswrap from file clrbook.gif */
extern const unsigned char clrbook[];

/* Created by reswrap from file copy.bmp */
extern const unsigned char copy[];

/* Created by reswrap from file config_gif.gif */
extern const unsigned char config_gif[];

/* Created by reswrap from file copyit.gif */
extern const unsigned char copyit[];

/* Created by reswrap from file cut.bmp */
extern const unsigned char cut[];

/* Created by reswrap from file deleteit.bmp */
extern const unsigned char deleteit[];

/* Created by reswrap from file desktop.bmp */
extern const unsigned char desktop[];

/* Created by reswrap from file details.bmp */
extern const unsigned char details[];

/* Created by reswrap from file dirup.bmp */
extern const unsigned char dirup[];

/* Created by reswrap from file enter.gif */
extern const unsigned char enter[];

/* Created by reswrap from file file_gif.gif */
extern const unsigned char file_gif[];

/* Created by reswrap from file foxbig.gif */
extern const unsigned char foxbig[];

/* Created by reswrap from file foxmini.gif */
extern const unsigned char foxmini[];

/* Created by reswrap from file goback.bmp */
extern const unsigned char goback[];

/* Created by reswrap from file goforw.bmp */
extern const unsigned char goforw[];

/* Created by reswrap from file gotodir.bmp */
extern const unsigned char gotodir[];

/* Created by reswrap from file home.gif */
extern const unsigned char home[];

/* Created by reswrap from file hosts.bmp */
extern const unsigned char hosts[];

/* Created by reswrap from file iconpath.gif */
extern const unsigned char iconpath[];

/* Created by reswrap from file linkit.gif */
extern const unsigned char linkit[];

/* Created by reswrap from file location.gif */
extern const unsigned char location[];

/* Created by reswrap from file maphost.bmp */
extern const unsigned char maphost[];

/* Created by reswrap from file mimetype.gif */
extern const unsigned char mimetype[];

/* Created by reswrap from file moveit.gif */
extern const unsigned char moveit[];

/* Created by reswrap from file paste.bmp */
extern const unsigned char paste[];

/* Created by reswrap from file pattern_gif.gif */
extern const unsigned char pattern_gif[];

/* Created by reswrap from file properties.bmp */
extern const unsigned char properties[];

/* Created by reswrap from file quit_gif.gif */
extern const unsigned char quit_gif[];

/* Created by reswrap from file renameit.gif */
extern const unsigned char renameit[];

/* Created by reswrap from file rotateleft.gif */
extern const unsigned char rotateleft[];

/* Created by reswrap from file rotateright.gif */
extern const unsigned char rotateright[];

/* Created by reswrap from file setbook.gif */
extern const unsigned char setbook[];

/* Created by reswrap from file setdir.gif */
extern const unsigned char setdir[];

/* Created by reswrap from file smallicons.bmp */
extern const unsigned char smallicons[];

/* Created by reswrap from file unmaphost.bmp */
extern const unsigned char unmaphost[];

/* Created by reswrap from file work.gif */
extern const unsigned char work[];

